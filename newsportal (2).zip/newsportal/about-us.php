<?php
include('includes/config.php');

?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>News Portal | About us</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">

  </head>

  <body>

    <!-- Navigation -->
    <?php include('includes/header.php');?>
    <!-- Page Content -->
    <div class="container">

<?php 
$pagetype='aboutus';
$query=mysqli_query($con,"select PageTitle,Description from tblpages where PageName='$pagetype'");
while($row=mysqli_fetch_array($query))
{

?>
      <h1 class="mt-4 mb-3"><?php echo htmlentities($row['PageTitle'])?>
  
      </h1>

      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Home</a>
        </li>
        <li class="breadcrumb-item active">About</li>
      </ol>

      <!-- Intro Content -->
      <div class="row">

        <div class="col-lg-12">
        <div class="container mt-5">
    <p class="text-center">Welcome to <strong>News Portal Management System</strong>, your go-to solution for efficient news publishing and management. Our platform is designed to help journalists, editors, and media houses create, manage, and distribute news content effortlessly.</p>
    
    <h2>Who We Are</h2>
    <p>We are a technology-driven company dedicated to revolutionizing the digital news industry. With advanced tools and innovative solutions, we provide an intuitive system to streamline editorial workflows and enhance audience engagement.</p>
    
    <h2>Features</h2>
    <ul>
        <li><strong>Easy Content Management:</strong> A user-friendly dashboard for smooth news publishing.</li>
        <li><strong>Multi-user Roles:</strong> Role-based access for journalists, editors, and administrators.</li>
        <li><strong>Automated Publishing:</strong> Schedule and automate news releases effortlessly.</li>
        <li><strong>SEO Optimization:</strong> Built-in tools for better visibility and reach.</li>
        <li><strong>Multimedia Integration:</strong> Easily add images, videos, and social media content.</li>
        <li><strong>Analytics & Insights:</strong> Track reader engagement with real-time data.</li>
    </ul>
    
    <h2>Our Mission</h2>
    <p>Our mission is to transform the way news is managed and delivered by providing a secure, scalable, and user-friendly platform that meets the evolving demands of the digital media landscape.</p>
    
    <h2>Why Choose Us?</h2>
    <ul>
        <li><strong>Secure & Reliable:</strong> Advanced security to protect your content.</li>
        <li><strong>Customizable Solutions:</strong> Tailored features to meet your needs.</li>
        <li><strong>24/7 Support:</strong> Dedicated assistance to ensure seamless operations.</li>
        <li><strong>Scalability:</strong> Suitable for news agencies of all sizes.</li>
    </ul>
    
    <p>Get started with <strong>News Portal Management System</strong> today!</p>
    
    <p>For more information, contact us at <a href="mailto:info@newsportal.com">info@newsportal.com</a> or visit our website <a href="#">www.newsportal.com</a>.</p>
</div>
        </div>
      </div>
      <!-- /.row -->
<?php } ?>
    
    </div>
    <!-- /.container -->

    <!-- Footer -->
 <?php include('includes/footer.php');?>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
